#include "graph.h"
#include <vector>

std::vector<int> check_graph(int N, int limit)
{
	bool flag = 1;
	flag &= query_edge(1, 2);
	flag &= query_edge(2, 3);
	flag &= (query_edge(1, 3) == 0);
	for(int i=4; i<=N; i++)
	{
		flag &= (query_edge(1, i) == 0);
		flag &= (query_edge(2, i) == 0);
		flag &= (query_edge(3, i) == 1);
	}
	if(!flag) return std::vector<int>();
	else return std::vector<int>({1, 2, 3});
}