#include <vector>

bool query_edge(int u, int v);
std::vector<int> check_graph(int N, int limit);